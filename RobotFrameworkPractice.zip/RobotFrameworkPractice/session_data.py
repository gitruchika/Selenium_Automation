url = "https://www.google.co.in"
browser = "chrome"
dummy_website_url = "https://automationbysqatools.blogspot.com/2021/05/dummy-website.html"