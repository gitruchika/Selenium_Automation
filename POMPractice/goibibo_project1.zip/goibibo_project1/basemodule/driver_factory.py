from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from resource import session_data as session_data
from utilities.get_logger import logger, log_dir_path
import datetime

log = logger


def get_driver(url):
        # if self.browser == 'chrome':
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.implicitly_wait(30)
        driver.get(url)
        log.info(f"url successfully launched: {url}")
        return driver