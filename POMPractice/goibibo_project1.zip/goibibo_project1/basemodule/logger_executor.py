import sys
import os
#os.path(sys.path[0])
from .get_logger import logger

logger.info("google_evening")