from resource import flight_page_data as data
from basemodule.basefile import SeleniumDriver
from resource import session_data as session_data
from selenium.webdriver.common.by import By
from utilities.get_logger import logger


class BookHotel(SeleniumDriver):
    def __init__(self, url=session_data.url, browser=session_data.browser):
        super(BookHotel, self).__init__(url=url, browser=browser)







