url = "https://www.goibibo.com/"
browser = "chrome"
dummy_website_url = "https://automationbysqatools.blogspot.com/2021/05/dummy-website.html"