source_location = "Mumbai"
dest_location = "Delhi"
departure_date = "Fri Nov 24 2023"


# dummy website details
dummy_website_header = "Dummy Ticket Booking Website"
booking_option = "Dummy hotel booking ticket - $400"