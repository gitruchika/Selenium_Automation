from basemodule.driver_factory import get_driver
from resource.session_data import *
import pytest

@pytest.fixture(scope="class")
def launch_browser(request):
    driver = get_driver(dummy_website_url)
    request.cls.driver = driver

