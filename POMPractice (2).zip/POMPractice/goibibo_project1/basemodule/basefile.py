from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from resource import session_data as session_data

class SeleniumDriver:
    def __init__(self, url=session_data.url, browser=session_data.browser, timeout=30):
        self.browser = browser
        self.url = url
        self.timeout = timeout
        self.driver = self.get_driver()
        self.wait = WebDriverWait(self.driver, self.timeout)

    def get_driver(self):
        #if self.browser == 'chrome':
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.implicitly_wait(self.timeout)
        driver.get(self.url)
        return driver

    def get_element(self, locator):
        element = self.wait.until(ec.presence_of_element_located(locator))
        return element

    def click_element(self, locator):
        element = self.get_element(locator)
        element.click()

    def send_data_field(self, data, locator):
        element = self.get_element(locator)
        element.clear()
        element.send_keys(data)


