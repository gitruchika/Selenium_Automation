source_location = "Mumbai"
dest_location = "Delhi"
departure_date = "Fri Nov 24 2023"